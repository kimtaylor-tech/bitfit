package com.example.bitfit

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val foodList = mutableListOf<FoodEntity>()
    private lateinit var foodRecyclerView: RecyclerView
    private lateinit var foodAdapter: FoodAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        foodRecyclerView = findViewById(R.id.foodRecyclerView)
        foodAdapter = FoodAdapter(foodList)
        foodRecyclerView.adapter = foodAdapter
        foodRecyclerView.layoutManager = LinearLayoutManager(this)

        val db = AppDatabase.getInstance(this)
        val foodDao = db.foodDao()

        lifecycleScope.launch {
            foodDao.getAll().collect { databaseList ->
                foodList.clear()
                foodList.addAll(databaseList)
                foodAdapter.notifyDataSetChanged()
            }
        }

        val addFoodLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                val foodName = data?.getStringExtra("FOOD_NAME_EXTRA")
                val calorieCount = data?.getStringExtra("CALORIE_COUNT_EXTRA")

                if (foodName != null && calorieCount != null) {
                    val newFood = FoodEntity(foodName = foodName, calorieCount = calorieCount)
                    lifecycleScope.launch(Dispatchers.IO) {
                        foodDao.insert(newFood)
                    }
                }
            }
        }

        val addFoodButton = findViewById<Button>(R.id.addFoodButton)
        addFoodButton.setOnClickListener {
            val intent = Intent(this, AddFoodActivity::class.java)
            addFoodLauncher.launch(intent)
        }
    }
}