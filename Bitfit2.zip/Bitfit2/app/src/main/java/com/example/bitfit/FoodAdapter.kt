package com.example.bitfit

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter(private val foods: List<FoodEntity>) : RecyclerView.Adapter<FoodAdapter.ViewHolder>() {


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val foodNameTextView: TextView = itemView.findViewById(R.id.foodNameTextView)
        val calorieCountTextView: TextView = itemView.findViewById(R.id.calorieCountTextView)
    }

    // This method creates a new ViewHolder by inflating the food_item.xml layout.
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        val foodView = inflater.inflate(R.layout.food_item, parent, false)
        return ViewHolder(foodView)
    }

    // This method binds the data from your list to the views in the ViewHolder.
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val food = foods[position]
        holder.foodNameTextView.text = food.foodName
        holder.calorieCountTextView.text = "${food.calorieCount} Calories"
    }

    // This method returns the total number of items in your data list.
    override fun getItemCount(): Int {
        return foods.size
    }
}